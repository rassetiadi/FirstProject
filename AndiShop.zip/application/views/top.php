<html>
  <head>
    <title>AndiShop</title>
    <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css"); ?>">
    <link rel="stylesheet" href="<?php echo base_url("assets/css/style.css"); ?>">
  </head>
  <body>

  </body>
</html>
