<html>
<head></head>
<body>

  <div class="container row" >
    <div class="login">
      <div class="row">
        <div class="col-md-12 loginTitle">
          <center><h1>Login</h1></center>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="">
            <div class="row">
              <div class="col-md-12">
                <p><input class ="form-control" type="text" name="login" value="" placeholder="Username or Email"></p>
                <p><input class ="form-control" type="password" name="password" value="" placeholder="Password"></p>
              </div>
            </div>
            <div class="row">
              <div class="col-md-8">
                <p class="remember_me">
                  <label>
                   <label>
                    <input type="checkbox" name="remember_me" id="remember_me">
                    Remember me on this computer
                  </label>
                  </label>
                </p>
              </div>
              <div class="col-md-4">
                <p class="submit" style="float:right;"><input type="submit" class="btn btn-primary" name="commit" value="Login"></p>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
